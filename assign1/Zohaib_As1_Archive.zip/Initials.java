/**
@author Zohaib Khan 3740572
**/

public class Initials {
  public static void main(String[] args) {
    System.out.println(" * * * * * *     *     * ");
    System.out.println("          *      *    * ");
    System.out.println("         *       *   * ");
    System.out.println("        *        *  * ");
    System.out.println("       *         * * ");
    System.out.println("      *          ** ");
    System.out.println("     *           * * ");
    System.out.println("    *            *  * ");
    System.out.println("   *             *   * ");
    System.out.println("  *              *    * ");
    System.out.println(" * * * * * *     *     * ");
  }
}