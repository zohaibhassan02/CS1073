/**
  @author Zohaib Khan 3740572
**/
public class MyFirstProgram {
  public static void main(String[] args) {
    System.out.println("Hello World");
  }
} //MyFirstProgram
