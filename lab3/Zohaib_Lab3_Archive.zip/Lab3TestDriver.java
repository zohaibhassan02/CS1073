/**
 This is a driver program for Camper class and Bunk class.
 @author Zohaib Khan 3740572
*/

public class Lab3TestDriver {

   public static void main (String[] args) {
   
      Camper obj1 = 
      new Camper ("Anna Marie Sullivan", 250.00, 148.30, 150.00, "Chickadee Lodge", 7, 155.75);
      
      Camper obj2 = 
      new Camper ("Porter Smith", 340.00, 277.88, 0, "Moose Hall", 16, 131.25);
      
      Camper obj3 = 
      new Camper ("Katharine Doucet", 565.30, 0, 175.00, "Brookside Cabin", 11, 385.00);
      
      obj1.setExcursionFees (178.80);
      
      obj2.setBunk ("Wolf Lodge", 9, 147.00);
      
      obj3.setCampFees (525.00);
      
      System.out.println("Mail Label 1: \n" 
      + obj1.getOnSiteMailLabel() + "\n"
      + "Total weekly fees owing: " + obj1.getTotalWeeklyFeesOwing()
      + "\n");
      
      System.out.println("Mail Label 2: \n" 
      + obj2.getOnSiteMailLabel() + "\n"
      + "Total weekly fees owing: " + obj2.getTotalWeeklyFeesOwing()
      + "\n");
      
      System.out.println("Mail Label 3: \n" 
      + obj3.getOnSiteMailLabel() + "\n"
      + "Total weekly fees owing: " + obj3.getTotalWeeklyFeesOwing()
      + "\n");
      
   }
   
} //end class