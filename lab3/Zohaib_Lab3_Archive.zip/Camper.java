/**
 Class to represent a child or teen 
 who is staying at the sleep-away camp.
 @author Zohaib Khan 3740572
*/

public class Camper {

   /**
    The full name of the child or teen.
   */
   private String name;

   /**
    The amount to be paid per week for the program.
   */
   private double campFees;

   /**
    The amount to be paid per week for extra activities.
   */
   private double excursionFees;
   
   /**
    The amount of funding the camper receives each week. 
   */
   private double fundingSupport;

   /**
    The bunk where the camper is staying.
   */
   private Bunk bunk;

   /**
    The constructor method to initialize the instance variables.
    @param nameIn the name of the camper.
    @param campFeesIn the amount to be paid per week for the program. 
    @param excursionFeesIn the amount to be paid per week for extra activities.
    @param fundingSupportIn the amount of funding the camper receives each week.
    @param bunkIn the bunk where the camper is staying.
   */
   public Camper (String nameIn, double campFeesIn, double excursionFeesIn, double fundingSupportIn, Bunk bunkIn) {
      name = nameIn;
      campFees = campFeesIn;
      excursionFees = excursionFeesIn;
      fundingSupport = fundingSupportIn;
      bunk = bunkIn;
   }
   
   /**
    The constructor method to initialize the instance variables.
    @param nameIn the name of the camper.
    @param campFeesIn the amount to be paid per week for the program. 
    @param excursionFeesIn the amount to be paid per week for extra activities.
    @param fundingSupportIn the amount of funding the camper receives each week.
    @param bunkNameIn the name of the building where the camper is staying.
    @param numIn the bed number where the camper is staying. 
    @param costIn the cost of the bunk where the camper is staying.
   */
   public Camper (String nameIn, double campFeesIn, double excursionFeesIn, double fundingSupportIn, String bunkNameIn, int numIn, double costIn) {
      name = nameIn;
      campFees = campFeesIn;
      excursionFees = excursionFeesIn;
      fundingSupport = fundingSupportIn;
      bunk = new Bunk (bunkNameIn, numIn, costIn);
   }

   /**
    Sets the name of the child or teen.
    @param nameIn the name of the child or teen.
   */
   public void setName (String nameIn) {
      name = nameIn;
   }

   /**
    Sets the amount to be paid per week for the program.
    @param campFeesIn the amount to be paid per week for the program.
   */
   public void setCampFees (double campFeesIn) {
      campFees = campFeesIn;
   }

   /**
    Sets the amount to be paid per week for extra activites.
    @param excursionFeesIn the amount to be paid per week for extra activities.
   */
   public void setExcursionFees (double excursionFeesIn) {
      excursionFees = excursionFeesIn;
   }
 
   /**
    Sets the amount of funding the camper receives per week.
    @param fundingSupportIn the amount of funding the camper receives per week.
   */
   public void setFundingSupport (double fundingSupportIn) {
      fundingSupport = fundingSupportIn;
   }

   /**
    Sets the bunk where the camper is staying.
    @param bunkIn the bunk where the camper is staying.
   */
   public void setBunk (Bunk bunkIn) {
      bunk = bunkIn;
   }
   
   /**
    Sets the bunk where the camper is staying.
    @param nameIn the name of the building where the camper is staying.
    @param numIn the bed number where the camper is staying. 
    @param costIn the cost of the bunk where the camper is staying.
   */
   public void setBunk (String nameIn, int numIn, double costIn) {
      bunk = new Bunk (nameIn, numIn, costIn);
   }

   /**
    This method returns the total fees that must 
    be paid to the camp this week.
    @return the total fees that must be paid to the camp this week.
   */
   public double getTotalWeeklyFeesOwing () {
      return campFees + excursionFees + bunk.getCost() - fundingSupport; 
   }
   
   /**
    This method returns a textual string that includes
    the camper's name and bunk location.
    @return the textual string that includes the 
    camper's name and bunk location.
   */
   public String getOnSiteMailLabel () {
      return name + "\n" 
      + bunk.getName() + ", bed " + bunk.getNum();
   }

} //end class
